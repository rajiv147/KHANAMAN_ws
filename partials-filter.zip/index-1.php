
<?php include('include/config.php'); ?>
<section id="home">
<?php include('header.php'); ?>
<!--search conternt-->
<!--<link rel="stylesheet" href="css/searchbarstyles.css">-->
<link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<!--search conternt-->

<!--jquery-search-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">

    		<div class="container">
   			<div class="row">
			<div class="col-md-offset-2 col-md-8" align="center">
          
<style>

<style>
  .ui-autocomplete {
    max-height: 100px;
    overflow-y: auto;
    /* prevent horizontal scrollbar */
    overflow-x: hidden;
  }
  /* IE 6 doesn't support max-height
   * we use height instead, but this forces the menu to always be this tall
   */
  * html .ui-autocomplete {
    height: 100px;
  }
  
body {
    background: url(images/home-bg.jpg) no-repeat center center fixed; 
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
	
}
</style>
     
                   
                       
               <section id="wrapper">
	
	<div id="main">
    <div class="ui-widget">
		<form>
			<input id="tags" type="text" name="search" id="search">
			<input type="submit" name="submit" class="solid" value="Search">
            </label>
          
		</form>
	</div>
      </div> 
      <?php
$search=$_REQUEST['searchto']; 
if(isset($_REQUEST['submit']))
{
	$query="select * from `names`";
	$res=mysql_query($query) or die (mysql_error());

 $row=mysql_fetch_array($res);
 {
	$name=$row['human'];
	//if($search==$name)
{
	 
		echo"<br>". $name."<br>";
		echo $row['fruit'];
	
	 }
 }

}
?>
      
      
       
    <br>
<br>
<br>
 <script>
  $(function() {
    var availableTags = [
      "Morhabadi",
      "Shivpuri",
      "Argora",
      "Hinoo",
      "JawaharNagar",
      "GandhiNagar",
      "Tharpakhna",
      "KusaiColony",
      "PuraniRanchi",
      "Kadru",
      "Kanke",
      "RatuRoad",
      "Bariatu",
      "Church",
      "Kokar",
      "Lalpur",
      "Kantatoli",
      "Argora",
      "Doranda",
      "Dhurwa",
      "Karamtoli",
      "ChurchRoad"
    ];
    $( "#tags" ).autocomplete({
      source: availableTags
    });
  });
  </script>
</head>
<body>
 
<!--<div class="ui-widget">
  <label for="tags"> </label>
  <input id="tags">
</div>-->
 
                   
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                                                 
                        
<div align="center">
    <meta name="description" content="">
<br>

    <meta name="author" content="">


    
   <div id="search">
      


<br>
<br>



<!--<script type="text/javascript" src="jquery-1.8.0.min.js"></script>
-->
</head>

<body>

    </div>
    </div></div></div></div>
    

    
	
	


<body>




<!--<a class="btn btn-default wow fadeInUp" data-wow-offset="50" data-wow-delay="0.6s">RANCHI</a>
<h1 style="color:#FFF;">restorent in ranchi area search</h1>

<a  class="btn btn-default wow fadeInUp" data-wow-offset="50" data-wow-delay="0.6s">HOME</a>
<a class="btn btn-default wow fadeInUp" data-wow-offset="50" data-wow-delay="0.6s">SEARCH</a>-->
</div>
    				</div>
    			</div>
    		</div>
            
            
    	</section>


</body>
</html>