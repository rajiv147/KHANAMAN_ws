<?php include('header-loger.php'); ?>
<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="css-filter/reset.css"> <!-- CSS reset -->
	<link rel="stylesheet" href="css-filter/style.css"> <!-- Resource style -->
	<script src="js-filter/modernizr.js"></script> <!-- Modernizr -->
  	
	<title>KHANA-MAN</title>
</head>
<body>
	   <main class="cd-main-content">
		<div class="cd-tab-filter-wrapper">
			<div class="cd-tab-filter">
				<!--<ul class="cd-filters">
					<li class="placeholder"> 
						<a data-type="all" href="#0">All</a> <!-- selected option on mobile
					</li> 
					<li class="filter"><a class="selected" href="#0" data-type="all">All</a></li>
					<li class="filter" data-filter=".color-1"><a href="#0" data-type="color-1">Color 1</a></li>
					<li class="filter" data-filter=".color-2"><a href="#0" data-type="color-2">Color 2</a></li>
				</ul>--> <!-- cd-filters -->
			</div> <!-- cd-tab-filter -->

		</div> <!-- cd-tab-filter-wrapper -->
<style>


</style>

		<section class="cd-gallery">
			<ul>
				<li class="mix color-1 check1 radio2 option3">
           
      
                <!--<img src="img/img-1.jpg" alt="Image 1">-->
                
                </li>
                  
                
                
                
                
                
				<!--<li class="mix color-2 check2 radio2 option2"><img src="img/img-2.jpg" alt="Image 2"></li>
				<li class="mix color-1 check3 radio3 option1"><img src="img/img-3.jpg" alt="Image 3"></li>
				<li class="mix color-1 check3 radio2 option4"><img src="img/img-4.jpg" alt="Image 4"></li>
				<li class="mix color-1 check1 radio3 option2"><img src="img/img-5.jpg" alt="Image 5"></li>
				<li class="mix color-2 check2 radio3 option3"><img src="img/img-6.jpg" alt="Image 6"></li>
				<li class="mix color-2 check2 radio2 option1"><img src="img/img-7.jpg" alt="Image 7"></li>
				<li class="mix color-1 check1 radio3 option4"><img src="img/img-8.jpg" alt="Image 8"></li>
				<li class="mix color-2 check1 radio2 option3"><img src="img/img-9.jpg" alt="Image 9"></li>
				<li class="mix color-1 check3 radio2 option4"><img src="img/img-10.jpg" alt="Image 10"></li>
				<li class="mix color-1 check3 radio3 option2"><img src="img/img-11.jpg" alt="Image 11"></li>
				<li class="mix color-2 check1 radio3 option1"><img src="img/img-12.jpg" alt="Image 12"></li>-->
				<!--<li class="gap">1</li>
				<li class="gap">22</li>
				<li class="gap">33</li>-->
			</ul>
            <style>
			.img
			{
				text-align:left;
			}
			.area_resorengt
			{
				background-color:#900;
			}
			.other_deteails
			{
				border:1px solid red;
			}
			</style>
			<div class="cd-fail-message">
            
            <div class="img">
            <img src="images/home-bg.jpg" width="40" height="60">
            <div class="area_resorengt">
            1111
            <div class="rating">
            2222
            <div class="other_deteails">
            3333
            </div>
            </div>
            </div>
            </div>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            </div>
		</section> <!-- cd-gallery -->

		<div class="cd-filter">
			<form>
				<div class="cd-filter-block">
					<h4>Search</h4>
					
					<div class="cd-filter-content">
						<input type="search" placeholder="Inter your area...">
					</div> <!-- cd-filter-content -->
				</div> <!-- cd-filter-block -->

				<div class="cd-filter-block">
					<h4>Check boxes</h4>

					<ul class="cd-filter-content cd-filters list">
						<li>
							<input class="filter" data-filter=".check1" type="checkbox" id="checkbox1">
			    			<label class="checkbox-label" for="checkbox1">Indian</label>
						</li>

						<li>
							<input class="filter" data-filter=".check2" type="checkbox" id="checkbox2">
							<label class="checkbox-label" for="checkbox2">Chinese</label>
						</li>

						<li>
							<input class="filter" data-filter=".check3" type="checkbox" id="checkbox3">
							<label class="checkbox-label" for="checkbox3">Fast-food</label>
						</li>
					</ul> <!-- cd-filter-content -->
				</div> <!-- cd-filter-block -->

				<div class="cd-filter-block">
					
					
					<div class="cd-filter-content">
						<div class="cd-select cd-filters">
							<!--<select class="filter" name="selectThis" id="selectThis">
								<option value="">Choose an option</option>
								<option value=".option1">Indian</option>
								<option value=".option2">Chinese</option>
								<option value=".option3">Fast-food</option>
								<option value=".option4">Continental</option>
							</select>-->
						</div> <!-- cd-select -->
					</div> <!-- cd-filter-content -->
				</div> <!-- cd-filter-block -->

				<div class="cd-filter-block">
					<h4>Radio buttons</h4>

					<ul class="cd-filter-content cd-filters list">
						<li>
							<input class="filter" data-filter="" type="radio" name="radioButton" id="radio1" checked>
							<label class="radio-label" for="radio1">All</label>
						</li>

						<li>
							<input class="filter" data-filter=".radio2" type="radio" name="radioButton" id="radio2">
							<label class="radio-label" for="radio2">Veg</label>
						</li>

						<!--<li>
							<input class="filter" data-filter=".radio3" type="radio" name="radioButton" id="radio3">
							<label class="radio-label" for="radio3">Nonveg </label>
						</li>-->
					</ul> <!-- cd-filter-content -->
				</div> <!-- cd-filter-block -->
			</form>

			<a href="#0" class="cd-close">Close</a>
		</div> <!-- cd-filter -->

		<a href="#0" class="cd-filter-trigger">Filters</a>
	</main> <!-- cd-main-content -->
<script src="js-filter/jquery-2.1.1.js"></script>
<script src="js-filter/jquery.mixitup.min.js"></script>
<script src="js-filter/main.js"></script> <!-- Resource jQuery -->
</body>
</html>