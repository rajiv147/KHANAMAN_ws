<!--header section-============================================================-->



	<link rel="stylesheet" href="assets/demo.css">
	<link rel="stylesheet" href="assets/header-login-signup.css">
	<link href='http://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>

</head>

<body>

<header class="header-login-signup">

	<div class="header-limiter">

		<h1><a href="#"><img src="images/logo.png"><span></span></a></h1>

		<!--<nav>
			<a href="#">Home</a>
			<a href="#" class="selected">Blog</a>
			<a href="#">Pricing</a>
		</nav>-->

		<ul>
			<li></li>
			<li><span style="color:#FFF"><?php  //echo  "hello :-  " . $_SESSION['firstname']; // it will print  ?></span></li><br>
<a href="index.php">logout</a>
		</ul>

	</div>

</header>

<!-- The content of your page would go here. -->




<!-- Demo ads. Please ignore and remove. -->










<!--header section-================================================================-->
